- Chạy chương trình nhập vào đường dẫn:
VD: F:/ABC/Test
 + Nếu là thư mục ổ đĩa thì nhập tên + ":"
VD: D:
- Chọn cấu hình, chọn các mục cấu hình rồi nhấn enter